import numpy as np
import pandas as pd

def provides_random_value(left_truncated_value, mean, std):
    flag = False
    while flag == False:
        value = np.random.normal(mean,std)
        
        if left_truncated_value <= value and value <= 2*mean-left_truncated_value:
            
            flag = True
            
    return value 

def Generates_instance():
    
    np.random.seed(seedd)
    
    V = range(Vertex) #Set of vertexs M U {0} Depot
    M = range(1, Vertex) #Set of farmers
    K = range(Products)  #Set of products
    T = range(Periods) #Set of periods
    
    #-------------------------------------------------------------------------------------------------------------------------------
    
    #generation of random coordinates
    coor = {i:(np.random.randint(0, size_grid), np.random.randint(0, size_grid)) for i in M}
    coor[0] = (size_grid/2, size_grid/2)
    
    Q = veh_factor
    
    #Travel time between (i,j). It is the same for all time t and it is in minutes. 
    
    c = {}
    for i in range(Vertex):
        for j in range(Vertex):
            if i !=j:
                
                dist = round(np.sqrt(((coor[i][0]-coor[j][0])**2)+((coor[i][1]-coor[j][1])**2)),3)/speed  #hours
                
                if j != 0:
                    dist = (dist*60) + time_per_supplier #incorporation of service time in the time matrix
                
                c[i,j] = dist
    
    #-------------------------------------------------------------------------------------------------------------------------------
    
    per_k = {k:perish for k in K}
    
    #Random selection of suppliers offering each product.   
    Mk = {}
    Km = {i:[] for i in M}    
    
    Markets = []
    for k in K:
        if k not in Mk.keys():
            Mk[k]=[]
        
        MarkesLen = np.ceil((Vertex-1)*increase_offering)
        M_help = [i for i in M]
        np.random.shuffle(M_help)
        
        while len(Mk[k]) < MarkesLen:

            selection = M_help[len(Mk[k])]
            
            if selection not in Mk[k]:
                
                Mk[k].append(selection)
                Km[selection].append(k)
                
                if selection not in Markets:
                    Markets.append(selection)
    
    for i in M:
        if i not in Markets:
            selection = np.random.randint(Products)
            Mk[selection].append(i)
            Km[i].append(selection)
    
    for k in K:
        Mk[k].sort()
        
    '''
    Random assignment of probability distributions for the supply and purchase prices of each product and supplier. 
    '''
    
    dist_p = {} #Dictionary storing the parameters of the probability distributions for the purchase prices
    
    if flag_correlated_price == True:  #The purchase prices are correlated per supplier
            
        EV_price = (upper_price + lower_price)/2.0 
        
        for k in K:
            for i in Mk[k]:   
                if k == Km[i][0]:
                    bandera = False 
                    
                    first =  np.random.uniform(lower_price, upper_price)
                    
                    if first <= EV_price:
                        bandera = True
                        
                    dist_p[i,k] = (first, first*std_price, bandera) #(mean, std, flag)
                    
                else:
                    
                    value = np.random.uniform(lower_price, upper_price)
                    
                    if dist_p[i,Km[i][0]][2] == True:
                        if value <= EV_price:
                            dist_p[i,k] = (value, value*std_price) #(mean, std)
                        else:
                            numero = EV_price + (EV_price - value)
                            dist_p[i,k] = (numero, numero*std_price)
                    else:
                        if value >= EV_price:
                            dist_p[i,k] = (value, value*std_price) 
                        else:
                            numero = EV_price + (EV_price - value)
                            dist_p[i,k] = (numero, numero*std_price)       
    else: 

        for k in K:
            for i in Mk[k]:
                valor = np.random.uniform(lower_price, upper_price)
                dist_p[i,k] = (valor, valor*std_price)     #(mean, std)            
    
                
    dist_q = {} #Dictionary storing the parameters of the probability distributions for the supply
    
    if flag_correlated_cap == True: #Supply is correlated by supplier
        

        EV_cap = (upper_quiantity + lower_quiantity)/2.0
        
        for k in K:
            
            for i in Mk[k]:   
                if k == Km[i][0]:
                    bandera = False 
                    first =  np.random.uniform(lower_quiantity, upper_quiantity)
                    if first <= EV_cap:
                        bandera = True
                        
                    dist_q[i,k] = (first, first*std_quiantity, bandera) #(mean, std, flag)
                    
                else:
                    value = np.random.uniform(lower_quiantity, upper_quiantity)
                    
                    if dist_q[i,Km[i][0]][2] == True:
                        if value <= EV_cap:
                            dist_q[i,k] = (value, value*std_quiantity) #(mean, std)
                        else:
                            numero = EV_cap + (EV_cap - value)
                            dist_q[i,k] = (numero, numero*std_quiantity)
                    else:
                        if value >= EV_cap:
                            dist_q[i,k] = (value, value*std_quiantity) 
                        else:
                            numero = EV_cap + (EV_cap - value)
                            dist_q[i,k] = (numero, numero*std_quiantity)

    else:
            
        for k in K:
            for i in Mk[k]:
                valor = np.random.uniform(lower_quiantity, upper_quiantity)
                dist_q[i,k] = (valor, valor*std_quiantity)

    '''
    Generation of replicates for the supply and purchase prices of each product and supplier
    Revenue value assignment and cost per back order
    '''
        
    p = {} #purchase prices 
    q = {} #supply
    
    r_EV = {} #revenue
    bo_EV = {} #back order cost
    
    p_EV = {} 
    q_EV = {}
        
    for k in K:
        for i in Mk[k]:
            
            #Expected value of the price and availability according to the stipulated limits.
            p_EV[i,k] = dist_p[i,k][0]
            q_EV[i,k] = dist_q[i,k][0]
            
            for t in T:
                #Real values of price and availability for each path evaluation (This is for policy evaluation)
                for path_eval in range(replicates):
                    
                    p[i,k,t,path_eval]= provides_random_value(1, dist_p[i,k][0],dist_p[i,k][1])
                    q[i,k,t,path_eval] = provides_random_value(0, dist_q[i,k][0],dist_q[i,k][1])
                                       
        r_EV[k] = np.average([p_EV[i,k] for i in Mk[k]])*(1+revenue_dist)
        bo_EV[k] = np.average([p_EV[i,k] for i in Mk[k]])*1000
    
    
    '''
    Random assignment of probability distributions for the demand. 
    '''
    
    dist_d = {}
    
    for k in K:
        mean = np.random.uniform(lower_demand, upper_demand)
        dist_d[k] = (mean, mean*std_demand)
    
    '''
    Generation of replicates for the demand
    '''
    
    d = {}
    d_EV = {}

    for k in K:
        d_EV[k] = dist_d[k][0]
        for t in T:
            
            #Real values of demand for each path evaluation (This is for policy evaluation)
            for path_eval in range(replicates):
                
                if flag_demand_cero_t_0 == True:
                    
                    if t == 0:
                        d[k,t,path_eval]  = 0
                    else:         
                        d[k,t,path_eval] = provides_random_value(0, dist_d[k][0],dist_d[k][1])
                else:         
                    d[k,t,path_eval] = provides_random_value(0, dist_d[k][0],dist_d[k][1])
                    
    
    return V, K, T, M, per_k, coor, c, Mk, Km, Q, dist_d, dist_p, dist_q, d, d_EV, p, p_EV, q, q_EV, r_EV, bo_EV

if __name__ == "__main__":

    #Problem size
    Vertex = 21 
    Products = 5
    Periods = 20
    size_grid = 250
    
    #Fleet parameters
    daily_time = 480 #maximum working time per vehicle in one period (minutes) 
    time_per_supplier = 10 #service time per supplier (minutes)
    veh_factor = 60 #vehicle capacity in hundreds of kilograms
    speed = 60 #vehicle speed kilometers per hour 
    
    #cost parameters
    increase_route = 1 #compensation in dollars per minute worked $/min
    revenue_dist = 0.1 #Revenue increase
    
    #Generator settings
    replicates = 20 #number of replicates for each source of uncertainty per period
    seedd = 10     
    flag_demand_cero_t_0 = True #True: Demand first period is cero for all replicates
    
    #maximum offer per supplier
    increase_offering = 0.3 
    
    #Price distribution information
    lower_price = 50 #$ dollars per hundred kg
    upper_price = 120 
    std_price = 0.1 
    
    #Available quantity distribution information
    lower_quiantity = 4 #hundreds of kilograms
    upper_quiantity  = 9
    std_quiantity = 0.1
    
    #Demand distribution information
    lower_demand = 10  #hundreds of kilograms
    upper_demand= 15 
    std_demand = 0.1
    
    flag_correlated_price = False
    flag_correlated_cap = False
    
    perish = 0.1 #loss due to perishability
    
    V, K, T, M, per_k, coor, c, Mk, Km, Q, dist_d, dist_p, dist_q, d, d_EV, p, p_EV, q, q_EV, r_EV, bo_EV = Generates_instance()
    